# Google Calendar Sync

## Dateien

- `supabase/functions/google-calendar-sync/index.ts` — Edge Function (Deno/Supabase)
- `src/hooks/useCalendarSync.ts` — React Hook für Frontend-Integration
- `src/components/calendar/types.ts` — TypeScript Typen

## Benötigte Secrets (Supabase)

- `GOOGLE_SERVICE_ACCOUNT_KEY` — JSON des Google Service Accounts
- `GOOGLE_CALENDAR_ID` — (optional, wird über app_settings konfiguriert)

## Benötigte DB-Tabellen

### calendar_events
```sql
CREATE TABLE public.calendar_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id TEXT NOT NULL,
  google_event_id TEXT UNIQUE,
  title TEXT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE,
  all_day BOOLEAN DEFAULT true,
  start_time TEXT,
  end_time TEXT,
  description TEXT,
  mitarbeiter TEXT[],
  calendar_type TEXT,
  project_type TEXT,
  synced_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
```

### app_settings (für Kalender-IDs)
```sql
CREATE TABLE public.app_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key TEXT UNIQUE NOT NULL,
  value TEXT NOT NULL,
  updated_at TIMESTAMPTZ,
  updated_by UUID
);

-- Kalender-IDs eintragen:
INSERT INTO app_settings (key, value) VALUES
  ('google_calendar_id_allgemein', 'deine-kalender-id@group.calendar.google.com'),
  ('google_calendar_id_kleinigkeiten', '...'),
  ('google_calendar_id_baustellen', '...');
```

## supabase/config.toml
```toml
[functions.google-calendar-sync]
verify_jwt = false
```

## Setup
1. Google Service Account erstellen & JSON-Key als Secret speichern
2. Kalender in Google Calendar freigeben für die Service Account E-Mail
3. DB-Tabellen erstellen
4. Edge Function deployen
